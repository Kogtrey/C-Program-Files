#include "LL.h"
#include "ContactNode.h"
#include <iostream>
#include <string>

using namespace std;

void LL::InsertFront(ContactNode* cn){
	(*cn).setNextNode(head);
	head = cn;
}
void LL::InsertBack(ContactNode* cn){
	(*tail).setNextNode(cn);
	tail = cn;
}
void LL::PrintList(){
	for(ContactNode* ptr = head; ; ptr = (*ptr).GetNext()){
		(*ptr).PrintContactNode();
		cout << endl;
		if(ptr == tail){
			break;
		}
	}
}
LL::LL(){
	head = nullptr;
	tail = nullptr;
}